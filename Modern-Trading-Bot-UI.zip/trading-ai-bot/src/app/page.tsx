"use client";

import { Button } from "@/components/ui/button";
import MainLayout from "@/components/layout/MainLayout";
import { motion } from "framer-motion";
import { FaChartLine, FaRobot, FaShieldAlt, FaSearch } from "react-icons/fa";
import Link from "next/link";

export default function Home() {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 md:pt-20 lg:pt-28">
        <div className="absolute inset-0 bottom-40 bg-gradient-to-b from-crypto-blue/10 to-transparent pointer-events-none z-0"></div>

        <div className="container relative z-10">
          <div className="flex flex-col items-center text-center mx-auto max-w-3xl pb-16">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
                <span className="gradient-text">AI-Powered</span> Trading Analysis at Your Fingertips
              </h1>
            </motion.div>

            <motion.p
              className="text-xl text-muted-foreground mb-8 px-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Upload any crypto chart and get instant, accurate analysis and predictions from our advanced AI model.
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Link href="/ai-tool">
                <Button size="lg" className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 button-glow transition-all">
                  Try AI Analysis Now
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Learn More
              </Button>
            </motion.div>
          </div>

          {/* Chart Preview */}
          <motion.div
            className="relative mx-auto max-w-5xl pb-20"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
          >
            <div className="relative crypto-card overflow-hidden shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-green-500/5"></div>
              <div className="relative p-6 rounded-xl overflow-hidden">
                <div className="bg-crypto-gray/40 rounded-lg p-6 backdrop-blur-sm border border-border/50">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-crypto-blue/20 flex items-center justify-center">
                        <FaChartLine className="text-primary" />
                      </div>
                      <div>
                        <h3 className="font-bold">BTC/USDT</h3>
                        <p className="text-xs text-muted-foreground">4h Chart</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-bold text-crypto-green">$42,586.24</p>
                      <p className="text-xs text-crypto-green">+2.34%</p>
                    </div>
                  </div>

                  <div className="h-64 w-full bg-gradient-to-r from-crypto-dark to-crypto-gray/50 rounded-lg overflow-hidden relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-muted-foreground text-sm">Chart visualization</p>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-crypto-dark/80 rounded-lg border border-border/50">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex-shrink-0 flex items-center justify-center mt-1">
                        <FaRobot className="text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-2">AI Analysis:</h4>
                        <p className="text-sm text-muted-foreground">The price is showing a bullish pattern with support at $41,200. Based on the double bottom formation, we can expect continued upward momentum. Recommended action: Buy with a stop loss at $40,900.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Glow effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-accent/20 rounded-xl blur-xl opacity-50 -z-10"></div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-crypto-gradient">
        <div className="container">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our AI trading assistant provides accurate analysis and predictions to help you make better trading decisions.
            </p>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {[
              {
                icon: <FaRobot className="h-6 w-6 text-primary" />,
                title: "AI-Powered Analysis",
                description: "Our advanced AI model analyzes any crypto chart and provides accurate predictions based on pattern recognition."
              },
              {
                icon: <FaChartLine className="h-6 w-6 text-primary" />,
                title: "Technical Pattern Detection",
                description: "Automatically identifies key technical patterns including support/resistance levels, trend lines, and chart formations."
              },
              {
                icon: <FaShieldAlt className="h-6 w-6 text-primary" />,
                title: "Risk Management",
                description: "Get tailored recommendations for stop-loss and take-profit levels to maximize your gains and protect your capital."
              },
              {
                icon: <FaSearch className="h-6 w-6 text-primary" />,
                title: "Instant Results",
                description: "Just upload a chart image and receive detailed analysis in seconds, no complex setup required."
              },
              {
                icon: <FaChartLine className="h-6 w-6 text-primary" />,
                title: "Multiple Timeframes",
                description: "Analyze charts from any timeframe - from 1-minute to monthly - for both short and long-term trading strategies."
              },
              {
                icon: <FaRobot className="h-6 w-6 text-primary" />,
                title: "Constant Learning",
                description: "Our AI model continuously improves by analyzing thousands of chart patterns and market conditions."
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="crypto-card p-6 h-full"
                variants={fadeInUp}
              >
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            className="crypto-card p-8 sm:p-12 max-w-5xl mx-auto relative overflow-hidden"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 opacity-50"></div>
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="max-w-lg">
                  <h2 className="text-3xl font-bold mb-3">Ready to analyze your charts?</h2>
                  <p className="text-muted-foreground mb-6">
                    Get started with our AI-powered chart analysis tool and make more informed trading decisions today.
                  </p>
                  <Link href="/ai-tool">
                    <Button className="bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 button-glow transition-all">
                      Try Free Analysis
                    </Button>
                  </Link>
                </div>
                <div className="h-40 w-40 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full flex items-center justify-center animate-pulse-slow">
                  <div className="h-32 w-32 bg-crypto-dark rounded-full flex items-center justify-center">
                    <FaRobot className="h-16 w-16 text-primary/70" />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </MainLayout>
  );
}
