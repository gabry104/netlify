"use client";

import MainLayout from "@/components/layout/MainLayout";
import { FaChartLine, FaRobot, FaUsers, FaServer } from "react-icons/fa";
import { motion } from "framer-motion";

export default function AboutPage() {
  return (
    <MainLayout>
      <div className="container py-16 md:py-24">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="gradient-text">TradingAI</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Advanced artificial intelligence for cryptocurrency chart analysis
            </p>
          </motion.div>

          <motion.div
            className="crypto-card p-8 mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h2 className="text-2xl font-bold mb-6">Our Mission</h2>
            <p className="text-lg mb-6">
              At TradingAI, we're dedicated to democratizing access to advanced trading analysis tools. Our mission is to provide traders of all experience levels with cutting-edge AI technology that was previously only available to professional traders and financial institutions.
            </p>
            <p className="text-lg">
              We believe that by combining the power of artificial intelligence with intuitive design, we can help traders make more informed decisions and increase their chances of success in the volatile cryptocurrency markets.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <motion.div
              className="crypto-card p-8 h-full"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FaRobot className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3">Our Technology</h3>
              <p>
                Our AI model has been trained on millions of chart patterns and market conditions across various timeframes and cryptocurrencies. It uses advanced pattern recognition algorithms to identify key technical patterns, support and resistance levels, and potential trend reversals with remarkable accuracy.
              </p>
            </motion.div>

            <motion.div
              className="crypto-card p-8 h-full"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="mb-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FaUsers className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3">Our Team</h3>
              <p>
                TradingAI was founded by a team of experienced traders, data scientists, and software engineers with a passion for cryptocurrency and artificial intelligence. Our diverse backgrounds and expertise allow us to develop innovative solutions that address the real challenges faced by traders in today's digital asset markets.
              </p>
            </motion.div>
          </div>

          <motion.div
            className="crypto-card p-8 relative overflow-hidden"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 pointer-events-none"></div>
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-6">How It Works</h2>
              <div className="grid gap-8 grid-cols-1 md:grid-cols-2">
                <div>
                  <div className="flex items-start gap-4 mb-6">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-bold">1</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">Upload Your Chart</h3>
                      <p className="text-muted-foreground">
                        Simply upload a screenshot of any cryptocurrency chart or provide a direct URL to the image.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 mb-6">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-bold">2</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">AI Analysis</h3>
                      <p className="text-muted-foreground">
                        Our advanced AI model processes the chart, identifying patterns, trends, and key levels.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-start gap-4 mb-6">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-bold">3</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">Get Predictions</h3>
                      <p className="text-muted-foreground">
                        Receive detailed analysis and price predictions based on recognized patterns.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="font-bold">4</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-2">Trade with Confidence</h3>
                      <p className="text-muted-foreground">
                        Use the AI's insights to make more informed trading decisions with specific action recommendations.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
}
