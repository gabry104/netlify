"use client";

import MainLayout from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { useState } from "react";
import { FaChevronDown } from "react-icons/fa";
import { cn } from "@/lib/utils";

export default function FAQPage() {
  const [openItem, setOpenItem] = useState<number | null>(null);

  const faqItems = [
    {
      question: "How accurate is the AI chart analysis?",
      answer: "Our AI model has been trained on millions of chart patterns and market data points, achieving an accuracy rate of around 70-75% in identifying major trend patterns and support/resistance levels. However, like any trading tool, it's not infallible and should be used as part of a comprehensive trading strategy rather than the sole decision-maker."
    },
    {
      question: "What types of chart patterns can the AI detect?",
      answer: "The AI can identify a wide range of technical patterns including Head and Shoulders, Double Tops/Bottoms, Triangles (ascending, descending, symmetrical), Wedges, Channels, Flag and Pennant formations, Cup and Handle patterns, and more. It can also identify key support and resistance levels."
    },
    {
      question: "How do I get the best results from the AI analysis?",
      answer: "For optimal results, upload clear and high-quality chart images that show sufficient price history (at least 3x the pattern's normal timeframe). Include visible candlesticks or price bars, and if possible, trading volume data. Charts from popular platforms like TradingView, Binance, or MetaTrader typically work best."
    },
    {
      question: "Can the AI analyze stocks and forex charts as well?",
      answer: "Yes, while our AI has been primarily optimized for cryptocurrency markets, it can effectively analyze technical patterns in stocks, forex, commodities, and other financial markets as these follow similar technical analysis principles."
    },
    {
      question: "How often is the AI model updated?",
      answer: "Our AI model undergoes continuous training and optimization. We release major updates on a quarterly basis, incorporating new patterns, improving accuracy, and adapting to evolving market conditions. Minor improvements are implemented weekly."
    },
    {
      question: "Is there an API available for integration?",
      answer: "Yes, we offer a developer API for seamless integration with trading platforms, websites, and apps. The API provides the same analysis capabilities as our web tool with additional customization options. Contact our team for API documentation and pricing."
    },
    {
      question: "How is my data handled and protected?",
      answer: "We prioritize user privacy and data security. Chart images you upload are temporarily stored only for the duration needed for analysis and are automatically deleted afterward. We do not store historical analysis results or link them to user accounts unless explicitly requested."
    },
    {
      question: "Do you offer trading advice or financial recommendations?",
      answer: "Our AI provides technical analysis of chart patterns and suggests possible scenarios based on historical pattern behavior. This is not financial advice or personalized trading recommendations. Always conduct your own research and consider consulting with a licensed financial advisor before making investment decisions."
    }
  ];

  return (
    <MainLayout>
      <div className="container py-16 md:py-24">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Frequently Asked <span className="gradient-text">Questions</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Everything you need to know about our AI chart analysis tool
            </p>
          </motion.div>

          <motion.div
            className="space-y-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {faqItems.map((item, index) => (
              <motion.div
                key={index}
                className="crypto-card overflow-hidden"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 * index }}
              >
                <div
                  className="p-6 flex justify-between items-center cursor-pointer"
                  onClick={() => setOpenItem(openItem === index ? null : index)}
                >
                  <h3 className="font-bold text-lg">{item.question}</h3>
                  <FaChevronDown
                    className={cn(
                      "h-4 w-4 text-muted-foreground transition-transform duration-300",
                      openItem === index && "transform rotate-180"
                    )}
                  />
                </div>
                <div
                  className={cn(
                    "overflow-hidden transition-all duration-300 ease-in-out",
                    openItem === index ? "max-h-96" : "max-h-0"
                  )}
                >
                  <div className="p-6 pt-0 text-muted-foreground bg-muted/20">
                    {item.answer}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            className="mt-16 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <p className="text-muted-foreground">
              Still have questions? Feel free to <a href="#" className="text-primary hover:underline">contact our support team</a>.
            </p>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
}
