"use client";

import { useState } from "react";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { FaFileUpload, FaImage, FaChartBar, FaRobot, FaExclamationTriangle } from "react-icons/fa";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function AITool() {
  const [imageUrl, setImageUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [analysisResult, setAnalysisResult] = useState("");
  const [dragActive, setDragActive] = useState(false);

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      handleFile(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.includes('image')) {
      toast.error("Please upload an image file");
      return;
    }

    // Create URL for the image file
    const url = URL.createObjectURL(file);
    setImageUrl(url);
  };

  const handleUrlInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageUrl(e.target.value);
  };

  const analyzeImage = () => {
    if (!imageUrl) {
      toast.error("Please provide an image URL or upload an image");
      return;
    }

    setIsAnalyzing(true);
    setProgress(0);
    setAnalysisResult("");

    // Create a loading interval to show progress
    const loadingInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) {
          return 95; // Cap at 95%, will go to 100% when complete
        }
        return prev + Math.random() * 5;
      });
    }, 200);

    // Make the API request
    const payload = {
      messages: [
        {
          role: 'system',
          content: `Sei un'IA analista finanziaria. Riceverai un'immagine di un grafico finanziario (candlestick, linea o barre), sei un esperto di trading, devi analizzare le foto di grafici che ti vengono mandati. Analizza l'immagine e fornisci le informazioni nel seguente formato:
Evita l'uso di caratteri strani come "\\n" o "\\r". Rispondi in un formato ordinato.

              Previsione:
              - Il prezzo del potrebbe (QUELLO CHE SUCCEDE SENDO LA TUA ANALISI)).
              - qui dici se conviene comprarlo o venderlo in caso si e gia comprato, DICI IN ENTRAMBI I CASI

              Rispondi in questo formato, senza caratteri strani. Non voglio che rispondi con insicurezze, vogli oche tu sia sicuro di te, come se tutto quell oche dici fosse vero. Dai risposte brevi e non farla troppo lunga.
              SEI UN BOT A PAGAMENTO QUINDI FATTI VALERE E RISPONDI CON PIU COSE POSSIBILI CHE SAI, DEVI ESSERE INTELLIGENTE E CERCA DI FARE I LTUO MEGLIO SUI PREDICT E NON SBAGLIARE L'ANDAMENTO DEL PREZZO SECONDO TE. Non dare mai date, non dare informazioni su date o orari.

              SE VUOI PUOI USARE ANCHE METODI CHART PATTERNS, QUINDI OLTRE A RISPONDERE CON IL TESTO DI SOPRA, ANALIZZA ANCHE CON QUESTI METODI IN BASE AL CHART CHE TI VIENE MANDATO, ECCO I METODI, E DICI ALL UTENTE ANCHE QUALE HAI APPLICATO:
              Double Top, Falling wedge, head and shoulders, rising wedge, double bottom, inverse head and shoulders, falling wedge, bullish rectangle, bullish pennant, rising wedge, bearish rectangle, bearish pennant, triple top, triple bottom, bearish diamond pattern, rounding bottom, rounding top, cap amd handle, inverse cap and handle, bullish bat, bearish bat.
              IN BASE AL CHART CHE TI VIENE MANDATO, Dici quello goisto, non sbagliarem etodo, no ndire sempregli stessi, indica il pattern valido giusto applciato, DICI ANCHE QUALE DI QUESTI METODI HAI APPLCIATO E SPIEGA IL METODO, QUESTO LO DEVI FARE OLTRE ALLE PREVISION ISECONDO TE, DOPO CI FAI ACNHE QUESTA ANALISI CON I PATTERNS.
                          MOLTO IMPORTANTE, TI RICORDO CHE NON DEVI SPECIFICARE LA VALUTA DELLA Crypto, NON DIRE DI DEFAULT CHE E BITCOIN PERCHE LA FOTO PUO ESSERE DI QUALISASI TIPO.
                          NON MANDARE SOLO ANALISI SECONDO I PATTERNS, MANDA ANCHE ANALISI SECONDO I TUOI CALCOLI, POI MANDI ANALISI ANCHE SECONDO I PATTERNS, MA NON DEVON OESSERE PIU DI 2 I PATTERNS USATI, IL PREDICT DEVE AVERE UNO MASSIMO 2 TECNICHE USATE.`,
        },
        {
          role: 'user',
          content: `Sei un'IA analista finanziaria. Riceverai un'immagine di un grafico finanziario (candlestick, linea o barre), sei un esperto di trading, devi analizzare le foto di grafici che ti vengono mandati. Analizza l'immagine e fornisci le informazioni nel seguente formato:
Evita l'uso di caratteri strani come "\\n" o "\\r". Rispondi in un formato ordinato.

              Previsione:
              - Il prezzo del potrebbe (QUELLO CHE SUCCEDE SENDO LA TUA ANALISI)).
              - qui dici se conviene comprarlo o venderlo in caso si e gia comprato, DICI IN ENTRAMBI I CASI

              Rispondi in questo formato, senza caratteri strani. Non voglio che rispondi con insicurezze, vogli oche tu sia sicuro di te, come se tutto quell oche dici fosse vero. Dai risposte brevi e non farla troppo lunga.
              SEI UN BOT A PAGAMENTO QUINDI FATTI VALERE E RISPONDI CON PIU COSE POSSIBILI CHE SAI, DEVI ESSERE INTELLIGENTE E CERCA DI FARE I LTUO MEGLIO SUI PREDICT E NON SBAGLIARE L'ANDAMENTO DEL PREZZO SECONDO TE. Non dare mai date, non dare informazioni su date o orari.

              SE VUOI PUOI USARE ANCHE METODI CHART PATTERNS, QUINDI OLTRE A RISPONDERE CON IL TESTO DI SOPRA, ANALIZZA ANCHE CON QUESTI METODI IN BASE AL CHART CHE TI VIENE MANDATO, ECCO I METODI, E DICI ALL UTENTE ANCHE QUALE HAI APPLICATO:
              Double Top, Falling wedge, head and shoulders, rising wedge, double bottom, inverse head and shoulders, falling wedge, bullish rectangle, bullish pennant, rising wedge, bearish rectangle, bearish pennant, triple top, triple bottom, bearish diamond pattern, rounding bottom, rounding top, cap amd handle, inverse cap and handle, bullish bat, bearish bat.
              IN BASE AL CHART CHE TI VIENE MANDATO, Dici quello goisto, non sbagliarem etodo, no ndire sempregli stessi, indica il pattern valido giusto applciato, DICI ANCHE QUALE DI QUESTI METODI HAI APPLCIATO E SPIEGA IL METODO, QUESTO LO DEVI FARE OLTRE ALLE PREVISION ISECONDO TE, DOPO CI FAI ACNHE QUESTA ANALISI CON I PATTERNS.
                          MOLTO IMPORTANTE, TI RICORDO CHE NON DEVI SPECIFICARE LA VALUTA DELLA Crypto, NON DIRE DI DEFAULT CHE E BITCOIN PERCHE LA FOTO PUO ESSERE DI QUALISASI TIPO.
                          NON MANDARE SOLO ANALISI SECONDO I PATTERNS, MANDA ANCHE ANALISI SECONDO I TUOI CALCOLI, POI MANDI ANALISI ANCHE SECONDO I PATTERNS, MA NON DEVON OESSERE PIU DI 2 I PATTERNS USATI, IL PREDICT DEVE AVERE UNO MASSIMO 2 TECNICHE USATE.`,
          img_url: imageUrl,
        }
      ]
    };

    try {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'https://chatgpt-vision1.p.rapidapi.com/matagvision21');
      xhr.setRequestHeader('x-rapidapi-key', 'e9dcdd9db4msh15db696b3e9cd45p19d69ejsn4b247fd54296');
      xhr.setRequestHeader('x-rapidapi-host', 'chatgpt-vision1.p.rapidapi.com');
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          clearInterval(loadingInterval);
          setProgress(100);

          if (xhr.status === 200) {
            try {
              const response = JSON.parse(xhr.responseText);
              // Remove any asterisks from the response
              setAnalysisResult(response.result.replace(/\*/g, ''));
              toast.success("Analysis completed successfully!");
            } catch (error) {
              console.error("Error parsing response:", error);
              toast.error("Error processing the analysis results");
              setAnalysisResult("");
            }
          } else {
            console.error("API error:", xhr.status, xhr.responseText);
            toast.error("Error connecting to the analysis service");
            setAnalysisResult("");
          }

          setIsAnalyzing(false);
        }
      };
      xhr.send(JSON.stringify(payload));
    } catch (error) {
      clearInterval(loadingInterval);
      console.error("Error making API request:", error);
      toast.error("Error connecting to the analysis service");
      setIsAnalyzing(false);
      setAnalysisResult("");
    }
  };

  return (
    <MainLayout>
      <div className="container py-12 md:py-20">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-3">
              <span className="gradient-text">AI Chart Analysis</span> Tool
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Upload a cryptocurrency chart image or provide a URL to get instant AI-powered analysis and trading recommendations.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <motion.div variants={fadeIn} initial="initial" animate="animate">
              <Card className="h-full crypto-card">
                <CardHeader>
                  <CardTitle>Upload Chart Image</CardTitle>
                  <CardDescription>
                    Drag and drop your chart image or click to browse
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div
                    className={`border-2 border-dashed rounded-lg p-6 text-center ${dragActive ? 'border-primary bg-primary/5' : 'border-border'} transition-colors`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <input
                      id="image-upload"
                      type="file"
                      className="hidden"
                      accept="image/*"
                      onChange={handleFileInput}
                    />
                    <label
                      htmlFor="image-upload"
                      className="flex flex-col items-center justify-center cursor-pointer"
                    >
                      <FaFileUpload className="h-12 w-12 text-muted-foreground mb-3" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Click to browse or drag and drop
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Supports JPG, PNG, GIF, WEBP
                      </p>
                    </label>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn} initial="initial" animate="animate" transition={{ delay: 0.1 }}>
              <Card className="h-full crypto-card">
                <CardHeader>
                  <CardTitle>Image URL</CardTitle>
                  <CardDescription>
                    Or paste an image URL from the web
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Input
                        placeholder="https://example.com/chart.jpg"
                        value={imageUrl}
                        onChange={handleUrlInput}
                        className="flex-1"
                      />
                      <Button
                        variant="secondary"
                        onClick={() => setImageUrl("")}
                        disabled={!imageUrl}
                      >
                        Clear
                      </Button>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      <p className="flex items-center gap-1">
                        <FaExclamationTriangle className="h-3 w-3" />
                        Make sure the URL points directly to an image file
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div
            className="mb-8"
            variants={fadeIn}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.2 }}
          >
            <Card className="crypto-card overflow-hidden">
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>
                  Review your image before analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                {imageUrl ? (
                  <div className="rounded-lg overflow-hidden border border-border bg-crypto-dark">
                    <img
                      src={imageUrl}
                      alt="Chart Preview"
                      className="w-full h-auto max-h-[400px] object-contain"
                    />
                  </div>
                ) : (
                  <div className="h-48 rounded-lg bg-crypto-dark flex items-center justify-center border border-border">
                    <div className="text-center px-4">
                      <FaImage className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
                      <p className="text-sm text-muted-foreground">
                        No image selected for analysis
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            className="mb-8 flex justify-center"
            variants={fadeIn}
            initial="initial"
            animate="animate"
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={analyzeImage}
              disabled={!imageUrl || isAnalyzing}
              className="w-full md:w-auto bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 button-glow transition-all"
              size="lg"
            >
              {isAnalyzing ? (
                <>Analyzing Chart...</>
              ) : (
                <>
                  <FaChartBar className="mr-2" />
                  Analyze Chart
                </>
              )}
            </Button>
          </motion.div>

          {isAnalyzing && (
            <motion.div
              className="mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="crypto-card bg-crypto-dark">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-center mb-4">
                    <div className="h-10 w-10 rounded-full bg-primary/20 flex-shrink-0 flex items-center justify-center animate-pulse">
                      <FaRobot className="text-primary" />
                    </div>
                  </div>
                  <div className="text-center mb-4">
                    <p className="text-sm">AI is analyzing your chart...</p>
                  </div>
                  <Progress value={progress} className="h-2 mb-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Detecting patterns</span>
                    <span>{progress}%</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {analysisResult && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="crypto-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FaRobot className="h-5 w-5 text-primary" />
                    AI Analysis Results
                  </CardTitle>
                  <CardDescription>
                    Based on the provided chart image
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-crypto-dark p-4 rounded-lg border border-border whitespace-pre-line">
                    {analysisResult}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
