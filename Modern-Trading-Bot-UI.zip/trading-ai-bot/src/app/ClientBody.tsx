"use client";

import { useEffect } from "react";

export default function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  // Remove any extension-added classes during hydration
  useEffect(() => {
    // This runs only on the client after hydration
    document.body.className = "antialiased bg-crypto-dark min-h-screen";
  }, []);

  return (
    <body className="antialiased bg-crypto-dark text-zinc-100 min-h-screen overflow-x-hidden" suppressHydrationWarning>
      <div className="absolute inset-0 bg-crypto-gradient bg-fixed opacity-20 pointer-events-none z-0"></div>
      <div className="relative z-10">
        {children}
      </div>
    </body>
  );
}
