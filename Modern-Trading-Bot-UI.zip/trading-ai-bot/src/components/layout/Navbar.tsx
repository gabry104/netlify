"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { FaRobot, FaChartLine, FaInfoCircle, FaQuestionCircle } from 'react-icons/fa';
import { cn } from '@/lib/utils';

export default function Navbar() {
  const pathname = usePathname();

  const navItems = [
    { name: 'Home', href: '/', icon: <FaChartLine className="mr-2" /> },
    { name: 'AI Tool', href: '/ai-tool', icon: <FaRobot className="mr-2" /> },
    { name: 'About', href: '/about', icon: <FaInfoCircle className="mr-2" /> },
    { name: 'FAQ', href: '/faq', icon: <FaQuestionCircle className="mr-2" /> },
  ];

  return (
    <motion.header
      className="sticky top-0 z-50 w-full backdrop-blur-lg bg-crypto-dark/70 border-b border-border/50"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <span className="text-2xl font-bold gradient-text">Trading<span className="text-accent">AI</span></span>
            </motion.div>
          </Link>

          <nav className="hidden md:flex gap-1">
            {navItems.map((item) => {
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "relative px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center",
                    isActive
                      ? "text-primary"
                      : "text-muted-foreground hover:text-primary"
                  )}
                >
                  {item.icon}
                  {item.name}
                  {isActive && (
                    <motion.div
                      className="absolute bottom-0 left-0 h-0.5 w-full bg-primary"
                      layoutId="navbar-indicator"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.2 }}
                    />
                  )}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="hidden sm:flex">
            Log In
          </Button>
          <Button
            size="sm"
            className="bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 button-glow transition-all"
          >
            Try Free
          </Button>
        </div>
      </div>
    </motion.header>
  );
}
