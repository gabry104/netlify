"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';
import { useState } from 'react';
import { FaRobot, FaChartLine, FaInfoCircle, FaQuestionCircle } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function MobileNav() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Home', href: '/', icon: <FaChartLine size={18} className="mr-3" /> },
    { name: 'AI Tool', href: '/ai-tool', icon: <FaRobot size={18} className="mr-3" /> },
    { name: 'About', href: '/about', icon: <FaInfoCircle size={18} className="mr-3" /> },
    { name: 'FAQ', href: '/faq', icon: <FaQuestionCircle size={18} className="mr-3" /> },
  ];

  return (
    <div className="md:hidden">
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="bg-crypto-dark border-r border-border/50 p-0">
          <div className="flex flex-col h-full">
            <div className="p-6 border-b border-border/50">
              <Link href="/" onClick={() => setIsOpen(false)}>
                <span className="text-xl font-bold gradient-text">Trading<span className="text-accent">AI</span></span>
              </Link>
            </div>

            <nav className="flex-1 p-4">
              <ul className="space-y-2">
                {navItems.map((item) => {
                  const isActive = pathname === item.href;

                  return (
                    <motion.li
                      key={item.href}
                      whileHover={{ x: 5 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Link
                        href={item.href}
                        onClick={() => setIsOpen(false)}
                        className={cn(
                          "flex items-center py-3 px-4 rounded-md text-base font-medium transition-colors",
                          isActive
                            ? "bg-muted text-primary"
                            : "hover:bg-muted/50 text-muted-foreground hover:text-primary"
                        )}
                      >
                        {item.icon}
                        {item.name}
                      </Link>
                    </motion.li>
                  );
                })}
              </ul>
            </nav>

            <div className="p-6 border-t border-border/50 space-y-3">
              <Button className="w-full" variant="outline">
                Log In
              </Button>
              <Button
                className="w-full bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 transition-all"
              >
                Try Free
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
