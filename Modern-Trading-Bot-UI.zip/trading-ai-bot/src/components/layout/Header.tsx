"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { FaRobot, FaChartLine, FaInfoCircle, FaQuestionCircle } from 'react-icons/fa';
import { Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useState } from 'react';
import { cn } from '@/lib/utils';

export default function Header() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Home', href: '/', icon: <FaChartLine className="mr-2" /> },
    { name: 'AI Tool', href: '/ai-tool', icon: <FaRobot className="mr-2" /> },
    { name: 'About', href: '/about', icon: <FaInfoCircle className="mr-2" /> },
    { name: 'FAQ', href: '/faq', icon: <FaQuestionCircle className="mr-2" /> },
  ];

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-lg bg-crypto-dark/70 border-b border-border/50">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center">
            <motion.div
              className="flex items-center"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <span className="text-2xl font-bold gradient-text">Trading<span className="text-accent">AI</span></span>
            </motion.div>
          </Link>

          <nav className="hidden md:flex gap-1">
            {navItems.map((item) => {
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "relative px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center",
                    isActive
                      ? "text-primary"
                      : "text-muted-foreground hover:text-primary"
                  )}
                >
                  {item.icon}
                  {item.name}
                  {isActive && (
                    <motion.div
                      className="absolute bottom-0 left-0 h-0.5 w-full bg-primary"
                      layoutId="navbar-indicator"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.2 }}
                    />
                  )}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          {/* Mobile menu */}
          <div className="md:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-crypto-dark border-l border-border/50 p-0">
                <div className="flex flex-col h-full">
                  <div className="p-6 border-b border-border/50">
                    <Link href="/" onClick={() => setIsOpen(false)}>
                      <span className="text-xl font-bold gradient-text">Trading<span className="text-accent">AI</span></span>
                    </Link>
                  </div>

                  <nav className="flex-1 p-4">
                    <ul className="space-y-2">
                      {navItems.map((item) => {
                        const isActive = pathname === item.href;

                        return (
                          <motion.li
                            key={item.href}
                            whileHover={{ x: 5 }}
                            transition={{ duration: 0.2 }}
                          >
                            <Link
                              href={item.href}
                              onClick={() => setIsOpen(false)}
                              className={cn(
                                "flex items-center py-3 px-4 rounded-md text-base font-medium transition-colors",
                                isActive
                                  ? "bg-muted text-primary"
                                  : "hover:bg-muted/50 text-muted-foreground hover:text-primary"
                              )}
                            >
                              {item.icon}
                              {item.name}
                            </Link>
                          </motion.li>
                        );
                      })}
                    </ul>
                  </nav>

                  <div className="p-6 border-t border-border/50 space-y-3">
                    <Button className="w-full" variant="outline">
                      Log In
                    </Button>
                    <Button
                      className="w-full bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 transition-all"
                    >
                      Try Free
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Desktop buttons */}
          <div className="hidden md:flex items-center gap-2">
            <Button variant="outline" size="sm" className="hidden sm:flex">
              Log In
            </Button>
            <Button
              size="sm"
              className="bg-gradient-to-r from-blue-600 to-accent hover:from-blue-700 hover:to-green-600 button-glow transition-all"
            >
              Try Free
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
