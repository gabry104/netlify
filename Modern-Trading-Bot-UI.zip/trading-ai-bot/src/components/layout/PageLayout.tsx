"use client";

import Navbar from './Navbar';
import MobileNav from './MobileNav';
import { motion } from 'framer-motion';

export default function PageLayout({
  children,
  showFullNavigation = true
}: {
  children: React.ReactNode;
  showFullNavigation?: boolean;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex items-center justify-between px-4 lg:px-6 h-16 md:hidden">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="flex items-center"
        >
          <span className="text-xl font-bold gradient-text">Trading<span className="text-accent">AI</span></span>
        </motion.div>
        <MobileNav />
      </div>

      {showFullNavigation && <Navbar />}

      <main className="flex-grow">
        {children}
      </main>

      <footer className="py-6 md:py-8 border-t border-border/50">
        <div className="container flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TradingAI. All rights reserved.
          </div>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-foreground transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
